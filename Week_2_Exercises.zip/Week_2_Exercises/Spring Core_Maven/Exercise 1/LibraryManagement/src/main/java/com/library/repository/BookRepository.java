package com.library.repository;

public class BookRepository {

    public void saveBook() {
        System.out.println("Saving a book to the repository");
    }
}