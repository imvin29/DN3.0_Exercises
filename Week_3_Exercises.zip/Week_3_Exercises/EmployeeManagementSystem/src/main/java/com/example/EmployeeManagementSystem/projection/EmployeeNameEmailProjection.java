package com.example.EmployeeManagementSystem.projection;

public interface EmployeeNameEmailProjection {
    String getName();
    String getEmail();
}
